server {
    listen 80;
    server_name admin.tepiagroup.pl;

    root /opt/tepia/backend/admin-site;
    index index.html;

    location / {
        try_files $uri $uri.html $uri/ /index.html;
    }

    location /api/ {
        proxy_pass http://127.0.0.1:4001/api/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location /uploads/ {
        proxy_pass http://127.0.0.1:4001/uploads/;
        proxy_set_header Host $host;
    }
}
